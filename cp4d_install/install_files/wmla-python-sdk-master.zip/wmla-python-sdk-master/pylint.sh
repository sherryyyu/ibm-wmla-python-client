#!/bin/bash

python -m pylint mysdk test --exit-zero
