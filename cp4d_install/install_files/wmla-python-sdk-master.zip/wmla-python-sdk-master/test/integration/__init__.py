# coding: utf-8

"""Integration tests"""

# This file is only here to get pylint to check the files in this directory